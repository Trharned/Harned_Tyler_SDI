// Tyler Harned
// Full Sail University - SDI_01
// Output Assignment
// July 9th, 2015

// Create variables and use them to tell everyone my name!

// All the variables being used.
var name = "Tyler"; // Tell everyone my name! (THIS IS A STRING VARIABLE)
var age = 21; // Tell everyone my age as well! (THIS IS A NUMBER VARIABLE)
var employed = true; // Tell people that I am currently employed. (THIS IS A BOOLEAN VARIABLE)
var jobOccupation = "Counter Sales"; // Discuss my job title. (THIS IS ANOTHER STRING VARIABLE)
var jobName = "Napa Auto Parts"; // Where I work at (THIS IS ANOTHER STRING VARIABLE)
var hobbies = "Gaming, Learning Code, and Developing Ideas!"; // List my hobbies! (Note: I forgot how to create a list.) (THIS IS ANOTHER STRING VARIABLE)

// Greet the user!
var greet = "Welcome! Let me show you who I am."; // Create a greet variable to include a message.
alert(greet); // Make a pop-up to the user.
console.log(greet); // log the results in the console.

// Alert the user my name and age.
alert("My name is "+name+". I am currently "+age+" years old."); // Show the user my name and age.
console.log("The creator's name is "+name+" and is "+age+" years old."); // Log the results in the console.

// Alert the user my job information.
alert("It's "+employed+" that I am currently employed.\n\nI currently do "+jobOccupation+" at "+jobName+".");// Alert the user some job information
console.log("The creator is employed: "+employed+".\nThe user does "+jobOccupation+" at "+jobName+"."); // Log the results of my occupation

// Alert the user my hobbies!
alert("My hobbies include: \n"+hobbies); // Alert the user my hobbies in a new line.
console.log("The creator's hobbies include: "+hobbies+"."); // Log my hobbies into the console.log

// Say good-bye to the user!
alert("It's time for me to go now!\nHope you've enjoyed and learned a little about me."); // Tell the user good-bye in a alert.
console.log("Terminating. Good-Bye!"); // Log the results that the end is near. Also that it's terminating.


// THIS IS OLD CODE

/*alert("Hell there!\nLet me tell you a little about myself in the console!\nPlease make sure you can view the console."); // Tell everyone what I will be doing and get them ready.
console.log("Hello world! My name is "+name+" and I am "+age+" years old. It is "+employed+" that I am currently employed at "+jobName+". What I do at "+jobName+" is "+jobOccupation+"."); // Combine all the things! This is where I discuss who I am, how old I am, what I do. Apart from that, I will discuss my hobby.
console.log("Well, that is it about me! One last thing before I go; My hobbies include "+hobbies+" See you later!"); // List my hobbies and say goodbye.*/

// Hope you enjoyed! Really had fun adding a lot of strings together. Also, forgot about the /n to make a new line. That's always handy. ;)